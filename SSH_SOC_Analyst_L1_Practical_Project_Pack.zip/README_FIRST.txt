SOC ANALYST L1 PRACTICAL PROJECT
1) Read the PDF report first.
2) evidence_timeline.csv is an analyst-prepared timeline derived from the synthetic challenge PDF.
3) detection_queries.spl contains starter Splunk searches. Replace INDEX_NAME and validate sourcetype/field mappings.
4) synthetic_soc_dashboard.png is a generated chart based on the fictional records. It is NOT a Splunk screenshot.
5) No actual Splunk execution was performed in creating this pack. For a live Splunk proof, ingest the original CSVs into a test index, run the SPL, and capture the real results.
6) All source IPs and events in this challenge are fictional/documentation-range examples.
